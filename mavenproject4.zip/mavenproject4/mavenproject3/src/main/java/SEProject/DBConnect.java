package SEProject;
import java.sql.*;
import javax.swing.*;

/**
 * DBConnect class to establish a connection with MySQL database
 */
public class DBConnect {
    
    // Static method to connect to the database
    public static Connection ConnectDb() {
        Connection conn = null;  // Declare conn variable here

        try {
            // Load the MySQL JDBC driver (com.mysql.cj.jdbc.Driver for newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Establish the connection to the database
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mvpresorts?zeroDateTimeBehavior=convertToNull&useSSL=false", "root", "");
            
            // If you want to show a message when connected (for testing purpose)
            JOptionPane.showMessageDialog(null, "Connected to the database successfully!");
            
            return conn; // Return the connection object
            
        } catch (ClassNotFoundException e) {
            // Handle ClassNotFoundException if the driver class is not found
            JOptionPane.showMessageDialog(null, "Database driver not found: " + e.getMessage());
        } catch (SQLException e) {
            // Handle SQLException if there's a connection issue
            JOptionPane.showMessageDialog(null, "Error while connecting to database: " + e.getMessage());
        }
        
        return null; // Return null in case of an error
    }
    
    public static void main(String[] args) {

    }
}
